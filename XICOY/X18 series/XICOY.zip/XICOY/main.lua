-- #########################################################################
-- #                                                                       #
-- # License GPLv3: https://www.gnu.org/licenses/gpl-3.0.html              #
-- #                                                                       #
-- # This program is free software; you can redistribute it and/or modify  #
-- # it under the terms of the GNU General Public License version 3 as     #
-- # published by the Free Software Foundation.                            #
-- #                                                                       #
-- # This program is distributed in the hope that it will be useful        #
-- # but WITHOUT ANY WARRANTY; without even the implied warranty of        #
-- # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
-- # GNU General Public License for more details.                          #
-- #                                                                       #
-- #########################################################################
--
-- =============================================================================
-- ETHOS XICOY Widget for XICOY TeleX adapter o XICOY HUBPRO
-- SCREEN 480x320 ( X18 / X18S / X18RS )
-- File:   : main.lua
-- Author  : ©aviat40
-- Guthub  : https://github.com/aviat40
-- History : Date        Version Author   Comment
--           ----------  ------- -------- ------------------------------------
--           01.01.2026  1.0.0   Aviat40  initial version
-- =============================================================================

local bitmapsPath = "./bitmaps/"
local fontPath = "./fonts/"
local audioPath = system.getAudioVoice()

local locale = system.getLocale()
local version = system.getVersion()
local screenWidth = version.lcdWidth
local screenHeight = version.lcdHeight

if version.major == 1 and version.minor <= 6 then 
	fontTimer = lcd.loadFont(fontPath.."xxxl.fnt")
else
	fontTimer = lcd.loadFont(fontPath.."xxxl_core.fnt")
end

local localeTexts = {
	xicoyParameters = {en="Xicoy parameters", fr="Paramètres Xicoy", de="Xicoy einstellungen", es="Parametros Xicoy", pl="Parametry Xicoy", pt="Parametros Xicoy"},
	widgetParameters = {en="Widget parameters", fr="Paramètres Widget", de="Widget einstellungen", es="Widget Parametros", pl="Parametry widżetu", pt="Parametros Widget"},
	engineType = {en="Engine type", fr="Type turbine", de="Turbine", es="Tipo de Turbina", pl="Typ turbiny", pt="Tipo turbina"},
	telemetryType = {en="Telemetry type", fr="Type télémetrie", de="Telemetry", es="Tipo de Telemetria", pl="Typ telemetrii", pt="Tipo de Telemetria"},
	sensorSet = {en="Sensor set", fr="Capteurs", de="Sensors", es="Sensores", pl="Tryb telemetrii", pt="Sensores"},
	sensorId = {en="Sensor Id", fr="Id module", de="Id module", es="ID del Sensor", pl="Id sensora", pt="ID Sensor"},
	colors = {en="Mask/Text Colors", fr="Couleurs Icone/Texte", de="Hintergrund/Text Farbe", es="Colores Mascaras/Texto", pl="Kolory Ikon/Tekstu", pt="Cores Mascaras/Texto"},
	tankCapacity = {en="Tank capacity", fr="Capacité réservoir", de="Tank Inhalt", es="Capacidade del Tanque", pl="Pojemność zbiornika paliwa", pt="Capacidade do Tanque"},
	fuelAlarm = {en="Fuel warning", fr="Alerte carburant", de="Kraftstoff Warnung", es="Alarma Combustible", pl="Rezerwa paliwa", pt="Alarme Combustível"},
	fileAlarm = {en="File Name", fr="Fichier alarme", de="Name De", es="Nombre fichero", pl="Nazwa pliku audio", pt="Nome Ficheiro"},
	haptic = {en="Low Fuel Haptic", fr="Vibreur alerte carburant", de="text9_de", es="Vibracion bajo combustible", pl="Wibracje", pt="Vibração combustível baixo"},
	switchPlay = {en="Fuel announce switch", fr="Inter lecture carburant", de="text10_de", es="Switch lectura combustible", pl="Przełącznik odczytu paliwa", pt="Switch leitura combustível"},
	}
	
local msg_table_xicoy = {
    [0]  = "HighTemp",
    [1]  = "Trim Low",
    [2]  = "SetIdle!",
    [3]  = "Ready",
    [4]  = "Ignition",
    [5]  = "FuelRamp",
    [6]  = "Glow Test",
    [7]  = "Running",
    [8]  = "Stop",
    [9]  = "FlameOut",
    [10] = "SpeedLow",
    [11] = "Cooling",
    [12] = "Ignit.Bad",
    [13] = "Start.Fail",
    [14] = "AccelFail",
    [15] = "Start On",
    [16] = "UserOff",
    [17] = "Failsafe",
    [18] = "Low RPM",
    [19] = "Reset",
    [20] = "RXPwFail",
    [21] = "PreHeat",
    [22] = "Battery!",
    [23] = "Time Out",
    [24] = "Overload",
    [25] = "Ign.Fail",
    [26] = "Burner On",
    [27] = "Starting",
    [28] = "SwitchOv",
    [29] = "Cal.Pump",
    [30] = "PumpLimi",
    [31] = "NoEngine",
    [32] = "PwrBoost",
    [33] = "Run-Idle",
    [34] = "Run-Max ",
    [35] = "Restart ",
    [36] = "No Status",
    [37] = "NO SENSOR",
    [100] = "NO ECU"
}	

local TELETYPE_NONE = 0
local TELETYPE_ADAPTER = 1
local TELETYPE_HUBPRO = 2

local ENGINETYPE_JET = 0
local ENGINETYPE_HELI = 1
local ENGINETYPE_TP = 2

local OPTION_BASIC = 0
local OPTION_EXTENDED = 1
local OPTION_MAXIMUM = 2

local function menu(widget)
	return{{"XICOY V"..widget.version, function() end}}
end

local function localize(key)
	return localeTexts[key][locale] or localTexts[key]["en"] or key
end

local function merge_tables(t1, t2)
    local t = {}
    for k, v in pairs(t1) do t[k] = v end
    for k, v in pairs(t2) do t[k] = v end
    return t
end	

local function build(widget)
	-- ============================
	-- X18 series and full screen	
	-- ============================	
	if widget.teletype == TELETYPE_NONE then return
		elseif widget.teletype == TELETYPE_ADAPTER then
		-- [INTERFACE] = {name, test ,optional ,source=nil, value=nil, rect={x, y, w, h}, font=nil, color, display, unit, decimal, flag, min, max}
				local sensors_extented = {		
				[0x4400] = {name = "EGT", test=0, optional=true, font=FONT_XL, rect={70, 170, 75, 25}, unit=UNIT_CELSIUS, min=-100, max=1000},
				[0x4401] = {name = "RPM", test=0, optional=true, font=FONT_XL, rect={70, 125, 140, 25}, unit=UNIT_RPM, max=300000},
				[0x4402] = {name = "ECU Thr", test=0, optional=true, font=FONT_XL, rect={160, 210, 65, 25}, unit=UNIT_PERCENT},
				[0x4403] = {name = "ECU Batt", test=0, optional=true, font=FONT_XL, rect={290, 170, 70, 25}, display=function(data) if data ~= nil then return (data/10) else return 10 end end, unit=UNIT_VOLT, decimal=2},
				[0x4404] = {name = "Pump RPM", test=0, optional=true, font=FONT_XL, rect={70, 210, 50, 25}},
				[0x4405] = {name = "Fuel left", test=0, optional=true, font=FONT_XL, rect={290, 210, 90, 25}, unit=UNIT_MILLILITER},
				[0x4406] = {name = "ECU Status", test=37, optional=true, font=FONT_XL, rect={200, 70, 180, 25}},
				}
			widget.sensors = sensors_extented		
			if widget.enginetype ~= ENGINETYPE_JET then 
				local sensors_extended_gearbox = {
				[0x4414] = {name = "GearBox RPM", test=0, optional=true, font=FONT_XL, rect={260, 125, 120, 25}, unit=UNIT_RPM, max=1000},
				[0x4415] = {name = "GearBox Temp", test=0, optional=true, font=FONT_XL, rect={160, 170, 100, 25}, unit=UNIT_CELSIUS},
				}
				widget.sensors = merge_tables(widget.sensors, sensors_extended_gearbox)
			end		
		elseif widget.teletype == TELETYPE_HUBPRO then
			if widget.option == OPTION_BASIC then    
				local sensors_basic = {
				[0x0400] = {name = "EGT", test=0, optional=true, font=FONT_XL, rect={70, 170, 75, 25}, unit=UNIT_CELSIUS, min=-1000, max=1000},
				[0x0500] = {name = "RPM", test=0, optional=true, font=FONT_XL, rect={70, 125, 140, 25}, display=function(data) if data ~= nil then return (data*100) else return 10 end end, unit=UNIT_RPM, max=300000},
				[0X0A20] = {name = "ECU Thr", test=0, optional=true, font=FONT_XL, rect={160, 210, 65, 25}, unit=UNIT_PERCENT},
				[0x0900] = {name = "ECU Batt", test=0, optional=true, font=FONT_XL, rect={290, 170, 70, 25}, unit=UNIT_VOLT, decimal=2},
				[0x0910] = {name = "Pump RPM", test=0, optional=true, font=FONT_XL, rect={70, 210, 50, 25}},
				[0x0A10] = {name = "Fuel Left", test=0, optional=true, font=FONT_XL, rect={290, 210, 90, 25}, unit=UNIT_MILLILITER},
				[0x0410] = {name = "ECU Status",test=37, optional=true, font=FONT_XL, rect={200, 70, 180, 25}},
				}
				widget.sensors = sensors_basic
				if widget.enginetype ~= ENGINETYPE_JET then 
					local sensors_basic_gearboxrpm = {
					[0x0A30] = {name = "Gearbox RPM", test=0, optional=true, font=FONT_XL, rect={260, 125, 120, 25}, unit=UNIT_RPM, max=1000},
					}
					widget.sensors = merge_tables(widget.sensors, sensors_basic_gearboxrpm)
				end
			else
				local sensors_hub = {
				[0x4400] = {name = "EGT", test=0, optional=true, font=FONT_XL, rect={70, 170, 75, 25}, unit=UNIT_CELSIUS, min=-100, max=2000},
				[0x4401] = {name = "RPM", test=0, optional=true, font=FONT_XL, rect={70, 125, 140, 25}, unit=UNIT_RPM, max=300000},
				[0x4402] = {name = "ECU Thr", test=0, optional=true, font=FONT_XL, rect={160, 210, 65, 25}, unit=UNIT_PERCENT},
				[0x4403] = {name = "ECU Batt", test=0, optional=true, font=FONT_XL, rect={290, 170, 70, 25}, display=function(data) if data ~= nil then return (data/10) else return 10 end end, unit=UNIT_VOLT, decimal=2},
				[0x4404] = {name = "Pump RPM", test=0, optional=true, font=FONT_XL, rect={70, 210, 50, 25}},
				[0x4405] = {name = "Fuel left", test=0, optional=true, font=FONT_XL, rect={290, 210, 90, 25}, unit=UNIT_MILLILITER},
				[0x4406] = {name = "ECU Status", test=37, optional=true, font=FONT_XL, rect={200, 70, 180, 25}},
				[0x4407] = {name = "HUB Temp", test=0, optional=true, font=FONT_S, rect={310, 260, 50, 15}, unit=UNIT_CELSIUS, min=-100, max=1000},
				[0x4408] = {name = "HUB Pressure", test=0, optional=true, font=FONT_S, rect={310, 280, 60, 15}},
				[0x4409] = {name = "HUB Altitude", test=0, optional=true, font=FONT_S, rect={310, 300, 50, 15}, unit=UNIT_METER},
				[0x440A] = {name = "Fuel Flow", test=0, optional=true, font=FONT_M, rect={285, 240, 75, 15}, unit=UNIT_MILLILITER_PER_MINUTE}
				}
				widget.sensors = sensors_hub
				if widget.option == OPTION_MAXIMUM then
					local sensors_maximum = {
					[0x440B] = {name = "Serial Number", optional=false},
					[0x440C] = {name = "ECU Batt used", optional=false, unit=UNIT_MILLIAMPERE_HOUR},
					[0x440D] = {name = "Engine Time", optional=false, unit=UNIT_SECOND, max=100000},
					[0x440E] = {name = "Pump Current", optional=false,unit=UNIT_AMPERE, decimals=1},
					}
					widget.sensors = merge_tables(widget.sensors, sensors_maximum)
				end
				if widget.enginetype ~= ENGINETYPE_JET then
					local sensors_extended_gearbox = {
					[0x4414] = {name = "GearBox RPM", test=0, optional=true, font=FONT_XL, rect={260, 125, 120, 25}, unit=UNIT_RPM, max=1000},
					}
					widget.sensors = merge_tables(widget.sensors, sensors_extended_gearbox)
				end
			end
		end
	
		for appId, sensor in pairs(widget.sensors) do
			sensor.source = system.getSource({category=CATEGORY_TELEMETRY_SENSOR, appId=appId})	
			if sensor.source == nil then
				if widget.teletype == TELETYPE_HUBPRO and widget.option == OPTION_BASIC then
					if appId == 0x0A10 or appId == 0x0A20 or appId == 0x0A30 then
						local newSensor1 = model.createSensor({type=SENSOR_TYPE_DIY})
						newSensor1:appId(appId)
						newSensor1:physId(widget.id-1)
						newSensor1:name(sensor.name)
						newSensor1:minimum(sensor.min)
						newSensor1:maximum(sensor.max)
					else 
						local newSensor1 = model.createSensor({type=SENSOR_TYPE_SPORT, appId=appId, physId=widget.id-1})
						newSensor1:name(sensor.name)
						newSensor1:minimum(sensor.min)
						newSensor1:maximum(sensor.max)
					end
				else
					local newSensor3 = model.createSensor({type=SENSOR_TYPE_DIY})
					newSensor3:appId(appId)
					newSensor3:physId(widget.id-1)
					newSensor3:name(sensor.name)
					newSensor3:minimum(sensor.min)
					newSensor3:maximum(sensor.max)
				end
			end
		end
		--logo
			--{x,y,width, height}
		widget.logo = {0, 0, 100, 50}
		--JAUGE
			--{x,y, width, height, font(%)}
		widget.jauge = {400, 0, screenWidth-400, screenHeight, FONT_XL}
		--MODELNAME
			--{x,y, font}	
		widget.modelName = {200, 10 , FONT_XL}
		--MASKS
			--{x, y, name}
		widget.masks = {
			{100, 65, widget.maskTurbine},
			{5, 130, widget.maskRpm},
			{15, 170, widget.maskTemp},	
			{15, 210, widget.maskPump},				
			{240, 170, widget.maskBattery},					
			{125, 210,widget. maskThro},
			{240, 205, widget.maskFuel},
			{20, 250, widget.maskTimer},
			}
		--TIMER
			--{x, y, width, height, font)
		widget.timer = {80, 240, 100, 35, fontTimer}
		--HUBPRO label
			--{x, y, font}
		widget.hubpro = {250, 275, FONT_S}
	
end

local function drawTimer(widget)
	local timer = system.getSource({category = CATEGORY_TIMER, member = 0})
			-- for test lcd.invalidate
		-- lcd.drawRectangle(widget.timer[1], widget.timer[2], widget.timer[3], widget.timer[4])
	lcd.font(widget.timer[5])
	if (timer ~= nil) and (timer:value() >= 0) then
		local timerSec = timer:value() % 60
		local timerMin = math.floor((timer:value() - timerSec) / 60)
		lcd.drawText(widget.timer[1], widget.timer[2],string.format("%02d : %02d", timerMin, timerSec))
	else
		lcd.color(RED)
		lcd.drawText(widget.timer[1], widget.timer[2],string.format("%02d : %02d", 0, 0))		
	end
end

local function drawStatus(x, y, status)
	local statuString = msg_table_xicoy[status] 
	lcd.drawText(x, y, statuString)
end

local function getPercentColor(percentColor, fuel, tank)
    if percentColor < (math.floor((fuel / tank)*100)) then
        return 0xFF, 0, 0
    else
       g = math.floor(0xDF * percentColor / 100)
       r = 0xDF - g
       return r, g, 0
    end
end

		--Monostable pour la lecture de quantité de carburant
local function checkFuelPlay(widget)
	if widget.switchPlay ~= nil then
		newSwitchState = widget.switchPlay:state()
		if newSwitchState and not previousSwitchState then
    		system.playNumber(widget.fuelRemaining, UNIT_MILLILITER, 0)
		end
		previousSwitchState = newSwitchState
	end
end

local function drawGaugeV(widget)
	local Id
	if widget.teletype == TELETYPE_HUBPRO and widget.option == OPTION_BASIC then
		Id = 0x0A10
	else 
		Id = 0x04405
	end
	--Gauge Background
	lcd.color(WHITE)
    lcd.drawFilledRectangle(widget.jauge[1], widget.jauge[2],widget.jauge[3], widget.jauge[4])
		-- Gauge color
	lcd.color(lcd.RGB(getPercentColor(widget.sensors[Id].value, widget.fuelAlarm, widget.tankCapacity)))
		-- Gauge bar
    local jaugeHeight =  math.floor(((widget.jauge[4]) / 100) * widget.sensors[Id].value)
    lcd.drawFilledRectangle(widget.jauge[1], (widget.jauge[4]-jaugeHeight), widget.jauge[3], jaugeHeight)
		-- Gauge frame outline
    lcd.color(BLACK)
    lcd.drawRectangle(widget.jauge[1], widget.jauge[2], widget.jauge[3], widget.jauge[4],2)
        -- Fuel remaining in %
    lcd.font(widget.jauge[5])
	local x= widget.jauge[1]+((screenWidth-widget.jauge[1])/2)
    lcd.drawNumber(x,widget.jauge[4]-jaugeHeight,widget.sensors[Id].value, UNIT_PERCENT, 0, CENTERED)
end

local function paint(widget)
		-- HubPRO label ifnot TELEX adapter
	if widget.teletype == TELETYPE_HUBPRO and widget.option ~= OPTION_BASIC then
		lcd.font(FONT_S)
		lcd.color(WHITE)
		lcd.drawText(342, 280, "mBar")
		lcd.font(widget.hubpro[3])
		lcd.color(widget.colorMask)
		lcd.drawText(widget.hubpro[1], widget.hubpro[2], "HUBPRO:")
	end
		-- Turbine logo
	lcd.drawBitmap(widget.logo[1], widget.logo[2], widget.turbineLogo, widget.logo[3], widget.logo[4])
		-- Masks
	lcd.color(widget.colorMask)
	for i, mask in ipairs(widget.masks) do
		lcd.drawMask(mask[1], mask[2], mask[3])
	end	 
		-- ModelName
	lcd.color(widget.colorText)
	lcd.font(widget.modelName[3])
	lcd.drawText(widget.modelName[1],widget.modelName[2],model.name())
		-- Datas Turbine
	for appId, sensor in pairs(widget.sensors) do
		if sensor.source ~= nil and sensor.optional == true then
			lcd.color(widget.colorText)
			lcd.font(sensor.font)
-- print(string.format("%X",appId).." "..sensor.name.." "..sensor.value)	
-- print(sensor.font)	
				-- Used for lcd.invalidate()
			-- lcd.drawRectangle(sensor.rect[1], sensor.rect[2], sensor.rect[3], sensor.rect[4])
			if appId == 0x4406 or appId == 0x0410 then
				drawStatus(sensor.rect[1], sensor.rect[2], sensor.value)
			elseif appId == 0x4405 or appId == 0x0A10 then
				widget.fuelRemaining = math.floor((sensor.value * widget.tankCapacity ) / 100)
				if (widget.fuelRemaining < widget.fuelAlarm) then
					lcd.color(RED)
				end
				lcd.drawNumber(sensor.rect[1], sensor.rect[2], widget.fuelRemaining, sensor.unit, sensor.decimal)
			else
				lcd.drawNumber(sensor.rect[1], sensor.rect[2], sensor.value, sensor.unit, sensor.decimal)
			end
		end
	end
	
	-- TIMER
	drawTimer(widget)	
	-- FUEL GAUGE VERTICAL
	drawGaugeV(widget)	
end

local function configure(widget)
	-- PANEL XICOY PARAMETERS
	local panelXicoy = form.addExpansionPanel(localize("xicoyParameters"))
	panelXicoy:open(false)	
		-- Telemetry Type
	line = form.addLine(localize("telemetryType"),panelXicoy)
	local telemetryField = form.addChoiceField(line, nil,
		{{"None", TELETYPE_NONE},{"Adapter", TELETYPE_ADAPTER},{"HubPro", TELETYPE_HUBPRO}}, 
		function() return widget.teletype end,
		function(value) widget.teletype = value
		end)
		-- Engine Type
	line = form.addLine(localize("engineType"),panelXicoy)
	local engineField = form.addChoiceField(line, nil,
		{{"Jet", ENGINETYPE_JET},{"Heli", ENGINETYPE_HELI},{"Turboprop", ENGINETYPE_TP}}, 
		function() return widget.enginetype end,
		function(value) widget.enginetype = value
		end)
		-- Sensor set
	line = form.addLine(localize("sensorSet"),panelXicoy)
	local sensorField = form.addChoiceField(line, nil,
		{{"Basic", OPTION_BASIC},{"Extended", OPTION_EXTENDED},{"Maximum", OPTION_MAXIMUM}}, 
		function() return widget.option end,
		function(value) widget.option = value
		end)
		-- Sensor ID
	line = form.addLine(localize("sensorId"),panelXicoy)
	local idField = form.addNumberField(line, nil, 1, 30,
		function() return widget.id end,
		function(value) widget.id = value
		end)	
		
	-- PANEL WIDGET PARAMETERS
	local panelWidget = form.addExpansionPanel(localize("widgetParameters"))
	panelWidget:open(false)	
		-- Colors
	line = form.addLine(localize("colors"),panelWidget)
	local slots = form.getFieldSlots(line,{0,70,"/",70})
	form.addColorField(line, slots[2],
		function() return widget.colorMask end,
		function(value) widget.colorMask = value 
		end)
	form.addStaticText(line, slots[3], "/")
	form.addColorField(line, slots[4], 
		function() return widget.colorText end,
		function(value) widget.colorText = value
		end)
		-- Fuel Tank capacity
	line = form.addLine(localize("tankCapacity"),panelWidget)
	local tankField = form.addNumberField(line, nil, 0, 9999,
		function() return widget.tankCapacity end,
		function(value) widget.tankCapacity = value
		end)
	tankField:default(2000)
	tankField:step(50)
	tankField:suffix(" ml")
		-- Fuel Tank low level
	line = form.addLine(localize("fuelAlarm"),panelWidget)
    local alarmField = form.addNumberField(line, nil, 0, widget.tankCapacity,
		function() return widget.fuelAlarm end,
		function(value) widget.fuelAlarm = value
		end)
	alarmField:default(600)
	alarmField:step(50)
	alarmField:suffix(" ml")
		-- File audio low level
	line = form.addLine(localize("fileAlarm"),panelWidget)
	local fileField = form.addFileField(line, nil, audioPath, "audio +ext",  
		function() return widget.fileName end, 
		function(value) widget.fileName = value
		end)
		-- Alarm Haptic
	line = form.addLine(localize("haptic"),panelWidget)
    local hapticField = form.addBooleanField(line, nil,
		function() return widget.haptic end,
        function(value) widget.haptic = value
        end)	
    	-- Source Play fuel value
    line = form.addLine(localize("switchPlay"),panelWidget)
    form.addSwitchField(line, nil, 
		function() return widget.switchPlay end,
		function(value) widget.switchPlay = value
		end)
end

local function setDefaults(widget)
    if widget.teletype == nil then widget.teletype = TELETYPE_HUBPRO end
    if widget.enginetype == nil then widget.enginetype = ENGINETYPE_JET end
	if widget.option == nil then widget.option = OPTION_EXTENDED end
    if widget.teletype == TELETYPE_HUBPRO and widget.id == nil then
		widget.id = 12
		else
		widget.id = 28
	end	
	if widget.colorText == nil then widget.colorText = lcd.RGB(248, 252, 248) end 
	if widget.colorMask == nil then widget.colorMask = lcd.RGB(192, 0, 192) end
	if widget.tankCapacity == nil then widget.tankCapacity = 2000 end
	if widget.fuelAlarm == nil then widget.fuelAlarm = 600 end
	if widget.fileName == nil then widget.fileName = "---" end
end

local function read(widget)
	widget.colorMask = storage.read("colorMask")
	widget.colorText = storage.read("colorText")
	widget.tankCapacity = storage.read("tankCapacity") or 2000
	widget.fuelAlarm = storage.read("fuelAlarm") or 600
	widget.fileName = storage.read("fileName")
	widget.haptic = storage.read("haptic")
	widget.switchPlay = storage.read("switchPlay")
    widget.teletype = storage.read("teletype")
    widget.enginetype = storage.read("enginetype")
    widget.option = storage.read("option")
    widget.id = storage.read("id")

    setDefaults(widget)
end

local function write(widget)
	storage.write("colorMask", widget.colorMask)
	storage.write("colorText", widget.colorText)
	storage.write("tankCapacity", widget.tankCapacity)
	storage.write("fuelAlarm", widget.fuelAlarm)
	storage.write("fileName", widget.fileName)
	storage.write("haptic", widget.haptic)
	storage.write("switchPlay", widget.switchPlay)
    storage.write("teletype", widget.teletype)
    storage.write("enginetype", widget.enginetype)
    storage.write("option", widget.option)
    storage.write("id", widget.id)
end

local function wakeup(widget)
	for appId, sensor in pairs(widget.sensors) do
			local newValue
			if sensor.source == nil then
				sensor.source = system.getSource({category=CATEGORY_TELEMETRY_SENSOR, appId=appId})
			end		
			if sensor.source:value()== nil then
					newValue = sensor.test
			elseif sensor.source ~= nil then
				if sensor.display ~= nil then
					newValue = sensor.display(sensor.source:value())
				else		
					newValue = sensor.source:value()
				end
			end
			if sensor.value ~= newValue then
				sensor.value = newValue
				if sensor.rect ~= nil then
					lcd.invalidate(sensor.rect[1], sensor.rect[2], sensor.rect[3], sensor.rect[4])
				end
			end
	end
		-- Update fuel Gauge
	lcd.invalidate(widget.jauge[1], widget.jauge[2], widget.jauge[3], widget.jauge[4])
		-- Update timer only when the timer change every second
	local timer = model.getTimer(0)
	local timerSec = timer:value() % 60
	if timerSec ~= newTimerSec then
		lcd.invalidate(widget.timer[1], widget.timer[2], widget.timer[3], widget.timer[4])
		newTimerSec = timerSec
	end						
		-- check if the switch is Pushed to annouce the Fuel volume
	checkFuelPlay(widget)		
		--Check the fuelLevel and play / haptic if switch on
	if (widget.fuelRemaining < widget.fuelAlarm) and (widget.fuelRemaining ~= 0) then
		if (widget.fuelWarningCount ~= 0) then
			system.playFile(audioPath.."/"..widget.fileName)
			if widget.haptic == true then
				system.playHaptic("- . -") 
			end		
			widget.fuelWarningCount = widget.fuelWarningCount - 1
		end
	end	
	if (widget.fuelRemaining == widget.tankCapacity ) then				-- Réinitialisation du compteur si Reset sans relancer la radio
		widget.fuelWarningCount = 1
	end
--[[
print("=========================")
local mem = {}
mem = system.getMemoryUsage()
print("Main Stack: "..mem["mainStackAvailable"])
print("RAM Avail: "..mem["ramAvailable"])
print("LUA RAM Avail: "..mem["luaRamAvailable"])
print("LUA BMP Avail: "..mem["luaBitmapsRamAvailable"])
print("=========================")
--]]

end

local function create()
	widget = {	
				version = "1.0.0",
				turbineLogo = lcd.loadBitmap(bitmapsPath.."xicoy.png"),
	            maskTurbine = lcd.loadMask(bitmapsPath.."turbine.png"),
	            maskBattery = lcd.loadMask(bitmapsPath.."battery.png"),
	            maskTemp = lcd.loadMask(bitmapsPath.."temp.png"),
	            maskRpm = lcd.loadMask(bitmapsPath.."rpm.png"),
	            maskPump = lcd.loadMask(bitmapsPath.."pump.png"),
	            maskThro = lcd.loadMask(bitmapsPath.."thro.png"),
	            maskFuel = lcd.loadMask(bitmapsPath.."fuel.png"),
	            maskTimer = lcd.loadMask(bitmapsPath.."timer.png"),
				colorText=colorText,
				colorMask=colorMask,
				tankCapacity=tankCapacity,
				fuelAlarm=fuelAlarm,
				fileName=fileName,
				haptic=haptic,
				switchPlay=switchPlay,
				sensors=sensors,
				teletype=teletype,
				fuelRemaining=0,
				enginetype=enginetype,
				fuelWarningCount= 1,
			}
	setDefaults(widget) 
	
	return widget	
end

local function init()
	local key = "xicoy"
	local name = "XICOY"
	system.registerWidget(
		{
			key=key, 
			name=name, 
			create=create, 
			paint=paint, 
			title=false, 
			build=build, 
			wakeup=wakeup, 
			configure=configure, 
			menu=menu, 
			read=read, 
			write=write })
end

return {init=init}